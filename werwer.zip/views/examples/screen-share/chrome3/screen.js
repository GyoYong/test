var idCount = 12;
var buttonElement = document.getElementById('screenButton');
const gotStream = screenStream => {
    const videoElement = document.getElementById('video');
    
	videoElement.src = URL.createObjectURL(screenStream);
    console.log("video src:" + src);
	videoElement.play();
};

const onFail = err => {
    console.log(err);
};
function start() {
    //successCallback = callback;
	console.log("werwerweR");
    // isChrome
    window.postMessage({ type: 'REQUEST_SCREEN_STREAM_ID', url: 'http://localhost:8080' }, '*');
    idCount++;
    isScreenEnded = false;
}

window.addEventListener('message', event => {
    const streamId = event.data.streamId;

    if (streamId) {
		console.log("슈바");
        navigator.mediaDevices.getUserMedia({
            audio: false, // or true
            video: {
                mandatory: {
                    chromeMediaSourceId: streamId,
                    chromeMediaSource: 'desktop',
                    maxWidth: window.screen.width,
                    maxHeight: window.screen.height
                    //...
              }
            }
        })
        .then(gotStream)
        .catch(onFail);
    } else {
      //... stream Id 가져오기 실패
    }
});

buttonElement.addEventListener('click', function(){
		start();
	
});