// Copyright 2013 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

chrome.runtime.onConnect.addListener(port => {
    port.onMessage.addListener(msg => {
        if (msg.type === 'REQUEST_SCREEN_STREAM_ID') {
            requestScreenStreamId(port, msg);
        }
        // ...
    });
});
function requestScreenStreamId(port, msg) {
    const sendMessage = {};
    const tab = port.sender.tab;
    tab.url = msg.url;

    chrome.desktopCapture.chooseDesktopMedia(['screen', 'window', 'tab'], tab, streamId => {
        if (streamId) {
            sendMessage.streamId = streamId;
            //...
        } else { // Stream Id를 가져오는데 실패한 경우
            //...
        }
    });

    port.postMessage(sendMessage);
}