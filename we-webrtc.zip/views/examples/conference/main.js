/*!
 *
 * WebRTC Lab
 * @author dodortus (codejs.co.kr / dodortus@gmail.com)
 *
 */

/*!
  간략한 시나리오.
  1. offer가 SDP와 candidate전송
  2. answer는 offer가 보낸 SDP와 cadidate를 Set한다.
  3. answer는 응답할 SDP와 candidate를 얻어서 offer한테 전달한다.
  4. offer는 응답 받은 SDP와 candidate를 Set한다.
*/

/*
TODO
 - 파폭 처리
 - hasWebCam 분기
*/
$(function() {
  console.log('Loaded webrtc');

  // cross browsing // 표준 웹 킷브라우스
  navigator.getUserMedia = navigator.getUserMedia || navigator.mozGetUserMedia || navigator.webkitGetUserMedia;
  var RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection;
  var RTCSessionDescription = window.RTCSessionDescription || window.mozRTCSessionDescription || window.webkitRTCSessionDescription;
  var RTCIceCandidate = window.RTCIceCandidate || window.mozRTCIceCandidate || window.webkitRTCIceCandidate;

  // for logic
  var socket = io();
  var roomId = null;
  var userId = Math.round(Math.random() * 999999) + 999999;
  var remoteUserId = null;
  var isOffer = null;
  var localStream = null;
 // var peer ; 
  var peerConnections ={};  // offer or answer peer
  var userList = {};
  var count;
  var iceServers = {
    'iceServers': [{
      'url': 'stun:stun.l.google.com:19302'
    }, {
      'url': 'turn:107.150.19.220:3478',
      'credential': 'turnserver',
      'username': 'subrosa'
    }]
  };
  var peerConnectionOptions = {
    'optional': [{
      'DtlsSrtpKeyAgreement': 'true'
    }]
  };
  var mediaConstraints = {
    'mandatory': {
      'OfferToReceiveAudio': true,
      'OfferToReceiveVideo': true
    }
  };

  // DOM
  var $body = $('body');
  var $roomList = $('#room-list');
  var $videoWrap = $('#video-wrap');
  var $tokenWrap = $('#token-wrap');
  var $uniqueToken = $('#unique-token');
  var $joinWrap = $('#join-wrap');

  /**
  * getUserMedia
  */
  function getUserMedia() {
    console.log('getUserMedia');

    navigator.getUserMedia({
      audio: true,
      video: {
        mandatory: {
          // 720p와 360p 해상도 최소 최대를 잡게되면 캡쳐 영역이 가깝게 잡히는 이슈가 있다.
          // 1920 * 1080 | 1280 * 720 | 858 * 480 | 640 * 360 | 480 * 272 | 320 * 180
          maxWidth: 1280,
          maxHeight: 720,
          minWidth: 1280,
          minHeight: 720,
          maxFrameRate: 24,
          minFrameRate: 18,
          maxAspectRatio: 1.778,
          minAspectRatio: 1.777
        },
        optional: [
          {googNoiseReduction: true}, // Likely removes the noise in the captured video stream at the expense of computational effort.
          {facingMode: "user"}        // Select the front/user facing camera or the rear/environment facing camera if available (on Phone)
        ]
      }
    }, function(stream) {
      localStream = stream;
      $videoWrap.append('<video id="local-video" muted="muted" autoplay="true" src="' + URL.createObjectURL(localStream) + '"></video>');
	  $body.addClass('room wait');
      $tokenWrap.slideDown(1000);
	  //로컬 비디오 설정....
		//
      if (isOffer) {
			//조인하면 합류하면 Offer 제안을 만든다.
			var arr = Object.keys(userList);

			//var result = null;
			for ( var i = 0; i < arr.length; i++ ){
					console.log("우리아이디",userList[arr[i]]);
				createPeerConnection(userList[arr[i]]);
				 createOffer(userList[arr[i]]);
				 
			}
			//for each ( var item in 
           // for each( var item in arr){
			//	console.log("알아줘" , arr);
			//}
		 
        
		
      }
    }, function() {
      console.error('Error getUserMedia');
    });
  }

  /**
  * createOffer
  * offer SDP를 생성 한다.
  */
  function createOffer(id) {
    console.log('createOffer', arguments);
	//
	var peer = createPeerConnection(id);
	if(!peer){
		return;
	}
    peer.addStream(localStream); // addStream 제외시 recvonly로 SDP 생성됨
    peer.createOffer(function(SDP) {
      // url parameter codec=h264
      if (location.search.substr(1).match('h264')) {
        SDP.sdp = SDP.sdp.replace("100 101 107", "107 100 101"); // for chrome < 57
        SDP.sdp = SDP.sdp.replace("96 98 100", "100 96 98"); // for chrome 57 <
      }
		
      peer.setLocalDescription(SDP); 
      console.log("Sending offer description", SDP);
      send({
        sender: userId, 
		receiver: id,
        to: 'all', 
        sdp: SDP 
      });
    }, onSdpError, mediaConstraints);
  }

  /**
  * createAnswer
  * offer에 대한 응답 SDP를 생성 한다.
  * @param {object} msg offer가 보내온 signaling
  */
  function createAnswer(msg) {
    console.log('createAnswer', arguments);
	if(peerConnections[msg.sender]){
		return;
	
	}
	var peer  = createPeerConnection(msg.sender);
	
    peer.addStream(localStream); //메시지온놈을 설정하고
    peer.setRemoteDescription(new RTCSessionDescription(msg.sdp), function() {
      peer.createAnswer(function(SDP) {
        peer.setLocalDescription(SDP);
        console.log("Sending answer to peer.", SDP);
        send({
          sender: userId,
		  receiver: msg.sender,
          to: 'all',
          sdp: SDP
        });
      }, onSdpError, mediaConstraints);
    }, function() {
      console.error('setRemoteDescription', arguments);
    });
  }

  /**
  * createPeerConnection
  * offer, answer 공통 함수로 peer를 생성하고 관련 이벤트를 바인딩 한다.
  */
  function createPeerConnection(id) {
    console.log('createPeerConnection', arguments);
	//내가 아닌 피어에대해서 연결을 해야함..
	//peer[]
	if(id == userId){
		return;
	}
	
	if(peerConnections[id]){
			
			return peerConnections[id];
	}
	console.log("안녕");
	

	var pc = new RTCPeerConnection(iceServers, peerConnectionOptions); 
	peerConnections[id] = pc;
  
	
    console.log('new Peer', pc);

    pc.onicecandidate = function(event) {
      if (event.candidate) {
        send({
          userId: userId,
		  receiver: id,
          to: 'all',
          label: event.candidate.sdpMLineIndex,
          id: event.candidate.sdpMid,
          candidate: event.candidate.candidate
        });
      } else {
        console.info('Candidate denied', event.candidate);
      }
    };
  ///여기 피어에는 연결되는데 
    pc.onaddstream = function(event) {
      console.log("Adding remote strem", event);

      $videoWrap.append('<video id="remote-video" autoplay="true" src="' + URL.createObjectURL(event.stream) + '"></video>');
      $body.removeClass('wait').addClass('connected');
    };

    pc.onremovestream = function(event) {
      console.log("Removing remote stream", event);
    };
  
	return pc;
  }

  /**
  * onSdpError
  */
  function onSdpError() {
    console.log('onSdpError', arguments);
  }

  /****************************** Below for signaling ************************/

  /**
  * send
  * @param {object} msg data
  */
  function send(data) {
    console.log('send', data);

    data.roomId = roomId;
    socket.send(data);
  }

  /**
  * onmessage
  * @param {object} msg data
  */
  function onmessage(data) {
    console.log('onmessage', data);

    var msg = data;
    var sdp = msg.sdp || null;
	var peer;
    if (!remoteUserId) {
      remoteUserId = data.userId; //원격유저아이디
    }
	console.log("받은자..", msg.receiver);
    // 접속자가 보내온 offer처리
    if (sdp) {
      if (sdp.type  == 'offer' && msg.receiver == userId ) {
        //createPeerConnection();
        console.log('Adding local stream...');
        createAnswer(msg);

      // offer에 대한 응답 처리
      } else if (sdp.type == 'answer' && msg.receiver == userId) {
        // answer signaling
		
		peer = createPeerConnection(msg.sender);
		if(!peer){
			return;
		}
        peer.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      }

    // offer, answer cadidate처리
    } else if (msg.candidate && msg.receiver == userId) {
      var candidate = new RTCIceCandidate({
        sdpMLineIndex: msg.label,
        candidate: msg.candidate
      });
	  peer = createPeerConnection(msg.userId);
	  if(!peer){
		return;
	  }
      peer.addIceCandidate(candidate);
    } else {
      //console.log()
    }
  }

  /**
   * setRoomToken
   */
  function setRoomToken() {
    //console.log('setRoomToken', arguments);

    if (location.hash.length > 2) {
      $uniqueToken.attr('href', location.href);//hash가 있으면 그대로둠.
    } else {
      location.hash = '#' + (Math.random() * new Date().getTime()).toString(32).toUpperCase().replace(/\./g, '-');
    }
  }

  /**
   * setClipboard
   */
  function setClipboard() {
    //console.log('setClipboard', arguments);

    $uniqueToken.click(function(){
      var link = location.href;
      if (window.clipboardData){
        window.clipboardData.setData('text', link);
        $.message('Copy to Clipboard successful.');
      }
      else {
        window.prompt("Copy to clipboard: Ctrl+C, Enter", link); // Copy to clipboard: Ctrl+C, Enter
      }
    });
  }

  /**
   * onFoundUser
   */
  function onFoundUser() {
    $roomList.html([
      '<div class="room-info">',
        '<p>당신을 기다리고 있어요. 참여 하실래요?</p>',
        '<button id="join">Join</button>',
      '</div>'].join('\n'));

    var $btnJoin = $('#join');
    $btnJoin.click(function() {
      isOffer = true;
      getUserMedia();
      $(this).attr('disabled', true);
    });

    $joinWrap.slideUp(1000);
    $tokenWrap.slideUp(1000);
  }

  /**
   * onLeave
   * @param {string} userId
   */
  function onLeave(userId) {
    if (remoteUserId == userId) {
      $('#remote-video').remove();
      $body.removeClass('connected').addClass('wait');
      remoteUserId = null;
    }
  }

  function pauseVideo(callback) {
    console.log('pauseVideo', arguments);
    localStream.getVideoTracks()[0].enabled = false;
    callback && callback();
  }

  function resumeVideo(callback) {
    console.log('resumeVideo', arguments);
    localStream.getVideoTracks()[0].enabled = true;
    callback && callback();
  }

  function muteAudio(callback) {
    console.log('muteAudio', arguments);
    localStream.getAudioTracks()[0].enabled = false;
    callback && callback();
  }

  function unmuteAudio(callback) {
    console.log('unmuteAudio', arguments);
    localStream.getAudioTracks()[0].enabled = true;
    callback && callback();
  }

  /**
   * initialize
   */
  function initialize() {
    setRoomToken(); //룸토큰만들고
    setClipboard(); // 클립보드 만듥로
    roomId = location.href.replace(/\/|:|#|%|\.|\[|\]/g, '');
	//룸아이디는 에네들다지움
    $('#start').click(function() {
      getUserMedia();
    }); //start가 클릭되면 겟유저미디어시작하고.

    $('#btn-camera').click(function() {
      var $this = $(this);
      $this.toggleClass('active');

      if ($this.hasClass('active')) {
        pauseVideo();
      } else {
        resumeVideo();
      }
    });

    $('#btn-mic').click(function() {
      var $this = $(this);
      $this.toggleClass('active');

      if ($this.hasClass('active')) {
        muteAudio();
      } else {
        unmuteAudio();
      }
    });
  }
  initialize();

  /**
   * socket handling
   */
  socket.emit('joinRoom', roomId, userId);
  socket.on('joinRoom', function(roomId, thisRoom) {
    console.log('joinRoom', arguments);
	userList = thisRoom;
		//console.log("뭔지알아야",userList[socket.id]);
	
	
	console.log("우리의 룸",thisRoom);
    if (Object.size(thisRoom) > 1) {
      onFoundUser(); //userList 1보다 크면 
    }
  });
  
  socket.on('leaveRoom', function(userId) {
    console.log('leaveRoom', arguments);
    onLeave(userId);// 룸을떠날때
  });

  socket.on('message', function(data) {
    onmessage(data);
  });
});

Object.size = function(obj) {
  var size = 0, key;
  for (key in obj) {
    if (obj.hasOwnProperty(key)) {
      size++;
    }
  }
  return size;
};
