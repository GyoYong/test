﻿

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
#!/usr/bin/env node
 
require('./common.js');
 
// key=roomname, value=room object
var roomList = [];
roomList.map_init();
 
function Room(name, master) {
    this.m_name = name;
    this.m_users = new Array();
    this.m_users.push(master);
}
 
Room.prototype.addUser = function(userId) {
    this.m_users.push(userId);
}
 
Room.prototype.delUser = function(userId) {
    this.m_users.splice(this.m_users.indexOf(userId),1);
}
 
Room.prototype.getUserList = function() {
    return this.m_users;
}
 
// External API
module.exports = {
    createRoom: function(roomname, master) {
        var newRoom = new Room(roomname, master);
         
        console.log("user number: " + newRoom.getUserList().length);
         
        roomList.map_set(roomname, newRoom);
        console.log("New room [" + roomname + "] was created..roomnum: "+roomList.map_keys().length);
    },
     
    join: function(roomname, user) {
        if (roomList.map_get(roomname)) {
            roomList.map_get(roomname).addUser(user);
        }
    },
     
    leave: function(roomname, user) {
        var room = roomList.map_get(roomname);
        if (room) {
            room.delUser(user);
            if (room.getUserList().length == 0) {
                roomList.map_del(roomname);
                return true;
            }
        }
        return false;
    },
     
    getRoomNameList: function() {
        return roomList.map_keys();
    },
     
    getUserListByRoom: function(roomname) {
        if (roomList.map_get(roomname) != null) {
            return roomList.map_get(roomname).getUserList();
        } else {
            return null;
        }
    },
     
    getRoomNameByUser: function(user) {
        var keys = roomList.map_keys();
         
        for(var i = 0; i < keys.length; i++) {
            var list = roomList[keys[i]].getUserList();
            if (list.indexOf(user) != -1) {
                return keys[i];
            }
        }
        return null;
    },
};